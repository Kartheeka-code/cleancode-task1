  
public interface SimpleInterest {
    Double simpleInterest();
}